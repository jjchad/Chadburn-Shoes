"""
Author: Joel Chadburn
Program: ChadburnShoes
Date of Last Revision: 12/17/22
The purpose of this program is to allow users to view information about
various shoes from 'Chadburn Shoes.' This program will also allow users to
enter personal information in order to 'place' an order.
"""
from tkinter import * #imports tkinter
from PIL import ImageTk, Image # imports the tools from pillow to allow dynamic backround image resizing.


#------------------------------------------------------------------------------------------------------------------------
#This portion of code is what is contained within the 'Our Story" window

def openOurStory(): #function that is called to open the Our Story Window
    global ourStoryImage # globalizes the variable that is used for the backround image
    def closeOurStory(): #allows exit button to close the 'our story' window
        ourStory.destroy() #destroys the window
    ourStory = Toplevel() #opens secondary window
    ourStory.title("Chadburn Shoes Story") #gives the window/program a name
    ourStory.geometry("1200x512") #sets the size of the secondary window 
    ourStoryImage = ImageTk.PhotoImage(file = 'OurStory.png') #sets variable to image
    ourStoryCanvas = Canvas(ourStory, width = 1200, height = 512) #sets size of the canvas(matches the root.geometry size)
    ourStoryCanvas.pack(fill = "both", expand = True) # configures canvas settings
    ourStoryCanvas.create_image(0,0, image = ourStoryImage, anchor = "nw")#puts my desired image onto the canvas
    ourStoryCanvas.create_text((600, 210), text = ("Chadburn Shoes has been revolutionizing footwear resale for over ten years.\n"
    "Our company was founded in a garage on November 8, 2011. On that day co-Founders Justin Zehr and Joel Chadburn \n"
    "were pondering the reasons why it was so difficult to get the latest kicks. They despised the websites and applications \n"
    "that were available for shoe purchasing at the time. Instead of continuing to suffer, they chose to do something about it. \n"
    "Welcome to Chadburn Shoes!"), font = ("Helvetica", 15)) #Displays our story in a formatted way

    ourStoryExit = Button(ourStory, text = "Exit", font = ("Helvetica", 15), fg = "white", command = closeOurStory) # Creates 'Exit' button with desired style
    ourStoryExitWindow = ourStoryCanvas.create_window(600, 450, anchor="nw", window = ourStoryExit) #places 'Exit' button onto the canvas
    


    def resizer(e): #this function allows the 'our story' window backround to dynamically resize when the window is resized
        global ourStoryImage1, resizedOurStoryImage, newOurStoryImage #globalizes variables used in the resizer function
        ourStoryImage1 = Image.open("OurStory.png") #sets image to variable
        resizedOurStoryImage = ourStoryImage1.resize((e.width, e.height), Image.ANTIALIAS) # variable used to store resized image
        newOurStoryImage = ImageTk.PhotoImage(resizedOurStoryImage) #creates variable that stores the resized image
        ourStoryCanvas.create_image(0,0, image = newOurStoryImage, anchor = "nw") #puts image onto canvas
        ourStoryCanvas.create_text((600, 210), text = ("Chadburn Shoes has been revolutionizing footwear resale for over ten years.\n"
    "Our company was founded in a garage on November 8, 2011. On that day co-Founders Justin Zehr and Joel Chadburn \n"
    "were pondering the reasons why it was so difficult to get the latest kicks. They despised the websites and applications \n"
    "that were available for shoe purchasing at the time. Instead of continuing to suffer, they chose to do something about it. \n"
    "Welcome to Chadburn Shoes!"), font = ("Helvetica", 15)) #Displays our story in a formatted way
     
    ourStory.bind('<Configure>', resizer) #passes size argument to the resizer function


#---------------------------------------------------------------------------------------------------------------------------------------------------------------
#The following portion of the code creates the code for the 'order information'
    
def makePurchase(): #opens the order placement window
    global closePurchaseWindow # globalizes the closePurchaseWindow function
    def closePurchaseWindow(): #function used to close the order placement window
        purchase.destroy() #destroys window
    purchase = Toplevel()#opens secondary window
    purchase.title("order") #gives window a title
    purchase.geometry("600x700") #sets window to proper size

    firstNameLabel = Label(purchase, text = "Enter your first name:", font = ("Helvetica", 15)) #creates label that asks for the customer's first name
    firstNameLabel.grid(row = 0, column =0, padx = 25) #puts first name label onto the screen
    global firstNameEntry #creates global variable
    firstNameEntry = Entry(purchase, width = 25, justify = 'center') #creates entry box where first name is to be entered
    firstNameEntry.grid(row = 2, column =0, padx = 25) #puts first name entry box onto the screen

    
    lastNameLabel = Label(purchase, text = "Enter your last name:", font = ("Helvetica", 15)) #creates label that asks for the customer's last name
    lastNameLabel.grid(row = 4, column = 0, padx = 25, pady = 5) #puts last name label onto the screen
    global lastNameEntry #creates global variable
    lastNameEntry = Entry(purchase, width = 50, justify = 'center') #creates entry box where last name is to be entered
    lastNameEntry.grid(row = 6, column = 0, padx = 25, pady = 5) #puts last name entry box onto the screen

    addressLabel = Label(purchase, text = "Enter the address to which you want your new shoes shipped:", font = ("Helvetica", 15)) #creates label that asks for the customer's address
    addressLabel.grid(row = 8, column = 0, padx = 25, pady = 5) #puts address label onto the screen

    streetLabel = Label(purchase, text = "Street:", font = ("Helvetica", 10)) #creates label that asks for the street name from the customer's address
    streetLabel.grid(row = 10, column = 0, padx = 25, pady = 5) #puts street label onto the screen
    global streetEntry #creates global variable
    streetEntry = Entry(purchase, width = 75, justify = 'center') #creates entry box where street is to be entered
    streetEntry.grid(row = 12, column = 0, padx = 25, pady = 5)  #puts street entry box onto the screen

    cityLabel = Label(purchase, text = "City:", font = ("Helvetica", 10)) #creates label that asks for the city name from the customer's address
    cityLabel.grid(row = 14, column = 0, padx = 25, pady = 5) #puts city label onto the screen
    global cityEntry #creates global variable
    cityEntry = Entry(purchase, width = 25, justify = 'center') #creates entry box where city is to be entered
    cityEntry.grid(row = 16, column = 0, padx = 25, pady = 5) #puts city entry box onto the screen

    stateLabel = Label(purchase, text = "State:", font = ("Helvetica", 10)) #creates label that asks for the state name from the customer's address
    stateLabel.grid(row = 18, column = 0, padx = 25, pady = 5) #puts state label onto the screen
    global stateEntry #creates global variable
    stateEntry = Entry(purchase, width = 10, justify = 'center') #creates entry box where state is to be entered
    stateEntry.grid(row = 20, column = 0, padx = 25, pady = 5) #puts state entry box onto the screen

    zipcodeLabel = Label(purchase, text = "Zipcode:", font = ("Helvetica", 10)) #creates label that asks for the zipcode from the customer's address
    zipcodeLabel.grid(row = 22, column = 0, padx = 25, pady = 5) #puts zipcode label onto the screen
    global zipcodeEntry #creates global variable
    zipcodeEntry = Entry(purchase, width = 10, justify = 'center')#creates entry box where zipcode is to be entered 
    zipcodeEntry.grid(row = 24, column = 0, padx = 25, pady = 5) #puts zipcode entry box onto the screen
    
    
    creditCardLabel = Label(purchase, text = "Enter your credit card number:", font = ("Helvetica", 15)) #creates label that asks for the customer's credit card number
    creditCardLabel.grid(row = 26, column = 0, padx = 25, pady = 5)#puts credit card label onto the screen
    global creditCardEntry #creates global variable
    creditCardEntry = Entry(purchase, width = 25, justify = 'center') #creates entry box where credit card is to be entered
    creditCardEntry.grid(row = 28, column =0, padx = 25, pady = 5) #puts credit card entry box onto the screen

    emailAddressLabel = Label(purchase, text = "Enter your email address:", font = ("Helvetica", 15)) #creates label that asks for the customer's email address
    emailAddressLabel.grid(row = 30, column =0, padx = 25, pady = 5) #puts email label onto the screen
    global emailAddressEntry #creates global variable
    emailAddressEntry = Entry(purchase, width = 75, justify = 'center') #creates entry box where email address is to be entered
    emailAddressEntry.grid(row = 32, column =0, padx = 25, pady = 5) #puts email address entry box onto the screen

    cancelPurchase = Button(purchase, text = "Go Back To Cart", font = ("Helvetica", 15), command = closePurchaseWindow) # creates button that closes the order placement window
    cancelPurchase.grid(row = 34, column = 0) # puts cancelPurchase button onto the screen

    confirmPurchase = Button(purchase, text = "Complete Purchase", font = ("Helvetica", 15), command = orderInformationValidation) #creates button that allows the customer to finalize purchase
    confirmPurchase.grid(row = 38, column = 0, pady = 5) # puts the confirmPurchase button onto the screen


#----------------------------------------------------------------------------------------------------------------------------------------------------------------------
#The following portion of code conducts input validation for the entry boxes that contain the customer's information. It also completes the purchase if no issues are found.

def orderInformationValidation(): #function that is called to validate the input in the entry boxes of the purchase window

    global firstNameValid #creates variable used to determine input validity
    global lastNameValid #creates variable used to determine input validity
    global streetValid #creates variable used to determine input validity 
    global cityValid #creates variable used to determine input validity
    global stateValid #creates variable used to determine input validity
    global zipcodeValid #creates variable used to determine input validity
    global creditCardValid #creates variable used to determine input validity
    global emailValid #creates variable used to determine input validity
    global masterValidity #creates variable used to determine input validity

 
    def isFloat(x): # creates function to help determine whether the input is valid
        """determines if user input is of float data type"""
        try:
            float(x) 
            return True
        except ValueError:
            return False 

    def error(): # function that displays error message box
        global errorPop #creates global variable
        def killErrorPop(): #function that closes the error message window
            errorPop.destroy() #destroys window
        errorPop = Toplevel() # creates secondary window
        errorPop.title("Error") #gives window a title
        errorPop.geometry = ("300x300") #sets window size
        errorPopLabel = Label(errorPop, text = "Your first and last name must be of string data type. \n"
                    "Your street name and city name must be of string data type. \n"
                    "Your state entry must be the capitalized two letter abbreviation for your state. \n"
                    "You must enter a 5 digit zipcode. \n"
                    "Your credit card number must be of numeric data type and be 15-16 digits long.\n"
                    "You must enter a valid email address. \n"
                    "Please note that we only ship within the United States. \n"
                    "Please go back through and make sure to enter your information correctly! \n"
                    "The invalid inputs that you have made have been cleared.", font = ("Helvetica", 10)) #creates a label that contains the error message
        errorPopLabel.grid(row = 0, column = 0) #puts the error message onto the screen
        closeErrorButton = Button(errorPop, text = "Close", command = killErrorPop) #creates button to close error message window
        closeErrorButton.grid(row = 1, column = 0, pady = 10) #places button in window
    def success(): # function that displays success message box
        global successPop #creates global variable
        def killSuccessPop(): #function that closes window
            successPop.destroy() #kills the window
            closeCart() #calls the close cart function
            closePurchaseWindow() #calls the closePurchaseWindow function
        successPop = Toplevel() #creates secondary window
        successPop.title("Congratulations") #gives window a title
        successPop.geometry = ("300x300") #sets window size
        successPopLabel = Label(successPop, text = "Congratulations, Your shoes are on their way!!!", font = ("Helvetica", 10)) #creates label that contains success message
        successPopLabel.grid(row = 0, column = 0) #places label in the window
        closeSuccessButton = Button(successPop, text = "Close", command = killSuccessPop) #creates button to close the success message box
        closeSuccessButton.grid(row = 1, column = 0, pady = 10) #places button onto screen

    if isFloat(firstNameEntry.get()) == True or len(firstNameEntry.get()) == 0: #Tests firstNameEntryBox
        firstNameEntry.delete(0, 'end')
        firstNameValid = False
    else:
        firstNameValid = True
    if isFloat(lastNameEntry.get()) == True or len(lastNameEntry.get()) == 0: # Tests lastNameEntryBox
        lastNameEntry.delete(0, 'end')
        lastNameValid = False
    else:
        lastNameValid = True
    if isFloat(streetEntry.get()) == True or len(streetEntry.get()) == 0: #Tests streetEntryBox
        streetEntry.delete(0, 'end')
        streetValid = False
    else:
        streetValid = True
    if isFloat(cityEntry.get()) == True or len(cityEntry.get()) == 0: #Tests CityEntryBox
        cityEntry.delete(0, 'end')
        cityValid = False
    else:
        cityValid = True
    if stateEntry.get() not in ('AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA', 'HI', 'ID', 'IL', 'IN',
                                'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV',
                                'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN',
                                'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'): #Tests stateEntryBox
        stateEntry.delete(0, 'end')
        stateValid = False
    else:
        stateValid = True
    if isFloat(zipcodeEntry.get()) == False or len(zipcodeEntry.get()) != 5: #Tests zipcodeEntryBox
        zipcodeEntry.delete(0, 'end')
        zipcodeValid = False
    else:
        zipcodeValid = True
    if isFloat(creditCardEntry.get()) == False or len(creditCardEntry.get()) not in (15, 16): # Tests creditCardEntryBox
        creditCardEntry.delete(0, 'end')
        creditCardValid = False
    else:
        creditCardValid = True
    if isFloat(emailAddressEntry.get()) == True or '@' not in emailAddressEntry.get(): #Tests emailAddressEntryBox
        emailAddressEntry.delete(0, 'end')
        emailValid = False
    else:
        emailValid = True
    validityList = [firstNameValid, lastNameValid, streetValid, cityValid, stateValid, zipcodeValid, creditCardValid, emailValid] #Creates list used to determine if all fields contain valid input
    if all(validityList) == True: # determines if all input is valid
        masterValidity = True
    else:
        masterValidity = False
    if masterValidity == True: #determines what course of action to take based on whether all input is valid
        success()
    else:
        error()


#----------------------------------------------------------------------------------------------------------------------------------------------------------------
#This portion of the code creates the cart window
        
def shoppingCart(): #function that is called to open the 'Cart' Window
    global cartImage #creates global variable
    global closeCart #creates global variable
    def closeCart(): #allows exit button to close the 'Cart' Window and clear 'Cart'
        shoeCart.clear() #clears out the shoe cart
        cart.destroy() #destroys the window
    cart = Toplevel() #opens secondary window
    cart.title("Cart") #gives the window/program a name
    cart.geometry("1200x512") #sets the size of the secondary window
    cartImage = ImageTk.PhotoImage(file = 'OurStory.png') #sets variable to image
    cartCanvas = Canvas(cart, width = 1200, height = 512) #sets size of the canvas(matches the root.geometry size)
    cartCanvas.pack(fill = "both", expand = True) # configures canvas settings
    cartCanvas.create_image(0,0, image = cartImage, anchor = "nw")#puts my desired image onto the canvas 

    cartExplanationLabel = Label(cart, text = "The list of shoes sthat you have added to your cart:", font = ("Helvetica", 15), fg = "black") #creates cartExplanationLabel
    cartExplanationLabelWindow = cartCanvas.create_window(50, 25, anchor="nw", window = cartExplanationLabel) #places 'cartExplanationLabel' onto the canvas



    cartListLabel = Label(cart, text = ',\n'.join(shoeCart), font = ("Helvetica", 15), fg = "black") #creates the cart list label
    cartListLabelWindow = cartCanvas.create_window(50, 100, anchor="nw", window = cartListLabel) #places cartList label onto canvas


    cartExit = Button(cart, text = "Clear Cart and Return to Shoes", font = ("Helvetica", 15), fg = "black", command = closeCart) #creates 'cart exit' button
    cartExitWindow = cartCanvas.create_window(700, 450, anchor = "nw", window = cartExit) #puts 'cart exit' button onto the canvas

    proceedToPurchase = Button(cart, text = "Make Purchase", font = ("Helvetica", 50), fg = "black", command = makePurchase) #creates the proceedToPurchase button
    proceedToPurchaseWindow = cartCanvas.create_window(550, 250, anchor = "nw", window = proceedToPurchase) #places the proceedToPurchase button onto the screen



    def resizer(e): #this function allows the secondary window backround to dynamically resize when the window is resized
        global cartImage1, resizedCartImage, newCartImage #globalizes variables used in the resizer function
        cartImage1 = Image.open("OurStory.png") #sets image to variable
        resizedCartImage = cartImage1.resize((e.width, e.height), Image.ANTIALIAS) #variable used to store resized image
        newCartImage = ImageTk.PhotoImage(resizedCartImage) #creates variable that stores the resized image
        cartCanvas.create_image(0,0, image = newCartImage, anchor = "nw") #puts image onto canvas
    cart.bind('<Configure>', resizer) #passes size argument to the resizer function

    
#----------------------------------------------------------------------------------------------------------------------------------------------------------------
#this portion of the code creates the shoe variables and required functions to make the cart system operate

global shoe1 #creates global variable
shoe1 = "Men's Mega Dunks, Size 13" #assigns text to shoe variable
global shoe2 #creates global variable
shoe2 = "Men's Fadeaway's, Size 9" #assigns text to shoe variable
global shoe3 #creates global variable
shoe3 = "Men's Chadburn Crossover 10's, size 10" #assigns text to shoe variable
global shoe4 #creates global variable
shoe4 = "Men's Skater Boi Specials, size 12"#assigns text to shoe variable 
global shoe5 #creates global variable
shoe5 = "Women's Pink Platoons, size 6" #assigns text to shoe variable
global shoeCart #creates global variable
shoeCart = [] #creates a list that can be used globally

def addShoe1(): #function to add shoe1 to the cart
    shoeCart.append(shoe1) #adds shoe to cart
def addShoe2(): #function to add shoe2 to the cart
    shoeCart.append(shoe2) #adds shoe to cart 
def addShoe3(): #function to add shoe3 to the cart
    shoeCart.append(shoe3) #adds shoe to cart
def addShoe4(): #function to add shoe4 to the cart
    shoeCart.append(shoe4)#adds shoe to cart 
def addShoe5(): #function to add shoe5 to the cart
    shoeCart.append(shoe5) #adds shoe to cart


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
#this portion of code contains the contents of the 'See Our Shoes' Page

def openShoes(): #function that is called to open the Our 'Shoes' Window
    global shoesImage
    def closeShoes(): #allows exit button to close the 'Shoes' Window
        shoes.destroy() #destroys the window
    shoes = Toplevel() #opens secondary window
    shoes.title("Shoes") #gives the window/program a name
    shoes.geometry("1200x512") #sets the size of the secondary window 
    shoesImage = ImageTk.PhotoImage(file = 'OurStory.png') #sets variable to image
    shoesCanvas = Canvas(shoes, width = 1200, height = 512) #sets size of the canvas(matches the root.geometry size)
    shoesCanvas.pack(fill = "both", expand = True) # configures canvas settings
    shoesCanvas.create_image(0,0, image = shoesImage, anchor = "nw")#puts my desired image onto the canvas


    def resizer(e): #this function allows the 'Shoes' window backround to dynamically resize when the window is resized
        global shoesImage1, resizedShoesImage, newShoesImage #globalizes variables used in the resizer function
        shoesImage1 = Image.open("OurStory.png") #sets image to variable
        resizedShoesImage = shoesImage1.resize((e.width, e.height), Image.ANTIALIAS) # variable used to store resized image
        newShoesImage = ImageTk.PhotoImage(resizedShoesImage) #creates variable that stores the resized image 
        shoesCanvas.create_image(0,0, image = newShoesImage, anchor = "nw") #puts image onto canvas 
    shoes.bind('<Configure>', resizer) #passes size argument to the resizer function

    #The following code creates labels for the 'shoes' page
    
    introLabel = Label(shoes, text = "Below, you will find a list of the various pairs of shoes that we currently have on hand. \n"
                       "Everything is sold as-is! Add items to your cart and make purchases as you please! \n"
                       "Thanks for shopping with us!", font = ("Helvetica", 15), fg = "black")
    megaDunksLabel = Label(shoes, text = "Men's Mega Dunks, Size 13", font = ("Helvetica", 15), fg = "black")
    fadeawaysLabel = Label(shoes, text = "Men's Fadeaways, Size 9", font = ("Helvetica", 15), fg = "black")
    crossover10Label = Label(shoes, text = "Men's Chadburn Crossover 10's, Size 10", font = ("Helvetica", 15), fg = "black")
    skaterBoisLabel = Label(shoes, text = "Men's Skater Boi Specials, size 12", font = ("Helvetica", 15), fg = "black")
    pinkPlatoonsLabel = Label(shoes, text = "Women's Pink Platoons, size 6", font = ("Helvetica", 15), fg = "black")

    #the following code items allow the labels to be displayed over the top of my canvas
    
    introLabelWindow = shoesCanvas.create_window(50, 25, anchor="nw", window = introLabel) 
    megaDunksLabelWindow = shoesCanvas.create_window(50, 125, anchor="nw", window = megaDunksLabel)
    fadeawaysLabelWindow = shoesCanvas.create_window(50, 200, anchor="nw", window = fadeawaysLabel)
    crossover10LabelWindow = shoesCanvas.create_window(50, 275, anchor="nw", window = crossover10Label)
    skaterBoisLabelWindow = shoesCanvas.create_window(50, 350, anchor="nw", window = skaterBoisLabel)
    pinkPlatoonsLabelWindow = shoesCanvas.create_window(50, 425, anchor="nw", window = pinkPlatoonsLabel)

    #The following code creates the add to cart buttons
    
    addToCart1  = Button(shoes, text = "Add to Cart", font = ("Helvetica", 10), fg = "black", command = addShoe1) # Creates add to cart button for the mega dunks
    addToCart2  = Button(shoes, text = "Add to Cart", font = ("Helvetica", 10), fg = "black", command = addShoe2) # Creates add to cart button for the fadeaways
    addToCart3  = Button(shoes, text = "Add to Cart", font = ("Helvetica", 10), fg = "black", command = addShoe3) # Creates add to cart button for the crossover 10s
    addToCart4  = Button(shoes, text = "Add to Cart", font = ("Helvetica", 10), fg = "black", command = addShoe4) # Creates add to cart button for the skaterBois
    addToCart5  = Button(shoes, text = "Add to Cart", font = ("Helvetica", 10), fg = "black", command = addShoe5) # Creates add to cart button for the pinkPlatoons

    #The following code items allow the buttons created above to be displayed over the top of my canvas
    
    addToCart1Window = shoesCanvas.create_window(300, 125, anchor="nw", window = addToCart1) #places addToCart1 button on the canvas
    addToCart2Window = shoesCanvas.create_window(280, 200, anchor="nw", window = addToCart2) #places addToCart2 button on the canvas
    addToCart3Window = shoesCanvas.create_window(410, 275, anchor="nw", window = addToCart3) #places addToCart3 button on the canvas
    addToCart4Window = shoesCanvas.create_window(360, 350, anchor="nw", window = addToCart4) #places addToCart4 button on the canvas
    addToCart5Window = shoesCanvas.create_window(325, 425, anchor="nw", window = addToCart5) #places addToCart5 button on the canvas 

    #The following code creates the 'exit' button for the 'shoes' window
    
    exitShoes = Button(shoes, text = "Exit", font = ("Helvetica", 15), fg = "black", command = closeShoes) # Creates 'Exit' button with desired style
    exitShoesWindow = shoesCanvas.create_window(1000, 450, anchor="nw", window = exitShoes) #places 'Exit' button onto the canvas

    #The following code creates the 'Cart' Button which opens the Cart Window
    
    shoppingCart1 = Button(shoes, text = "Cart", font = ("Helvetica", 15), fg = "black", command = shoppingCart) # Creates 'Cart' button with desired style
    shoppingCartWindow = shoesCanvas.create_window(1000, 25, anchor="nw", window = shoppingCart1) #places 'Cart' button onto the canvas

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
#this portion of code is what is contained in the main window of the program

root = Tk() #creates and opens the main gui window
def shutDownProgram(): #allows close button to close the program
    root.destroy() #destroys the window



root.title("Chadburn Shoes") #gives the window/program a name
root.geometry("1200x512") #sets the size of the main window
bg = ImageTk.PhotoImage(file = "HomePageChadburnShoes2.png") #sets variable to image
homeCanvas = Canvas(root, width = 1200, height = 512) #sets size of the canvas(matches the root.geometry size)
homeCanvas.pack(fill = "both", expand = True) # configures canvas settings
homeCanvas.create_image(0,0, image = bg, anchor = "nw")#puts my desired image onto the canvas
ourStoryButton = Button(root, text = "Our Story", font = ("Helvetica", 30), fg = "white", command = openOurStory) # Creates 'our story button' with desired style
ourStoryButtonWindow = homeCanvas.create_window(300, 256, anchor="nw", window = ourStoryButton) # Places the Button over the top of the canvas
seeOurShoesButton = Button(root, text = "See Our Shoes", font = ("Helvetica", 30), fg = "white", command = openShoes) #Creates 'seeOurShoes' button with desired style
seeOurShoesButtonWindow = homeCanvas.create_window(700, 256, anchor="nw", window = seeOurShoesButton) # Places the button over the top of the canvas

closeProgram = Button(root, text = "Close", font = ("Helvetica", 15), fg = "white", command = shutDownProgram) # Creates 'Close' button with desired style
closeProgramtWindow = homeCanvas.create_window(1000, 450, anchor="nw", window = closeProgram) #places 'Close' button onto the canvas


def resizer(e): #this function allows the main program window backround to dynamically resize when the window is resized
    global bg1, resized_bg, new_bg #globalizes variables used in the resizer function 
    bg1 = Image.open("HomePageChadburnShoes2.png") #sets image to variable
    resized_bg = bg1.resize((e.width, e.height), Image.ANTIALIAS) #variable used to store resized image
    new_bg = ImageTk.PhotoImage(resized_bg) #creates variable that stores the resized image
    homeCanvas.create_image(0,0, image = new_bg, anchor = "nw") #puts image onto canvas
root.bind('<Configure>', resizer) #passes size argument to the resizer function
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------




root.mainloop() #ensures that the mainloop is continuously traversed until the program is closed.

